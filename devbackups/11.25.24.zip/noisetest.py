import noise

value = noise.pnoise1(0.5)
print(value)